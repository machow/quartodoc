from .index import admon_plugin  # noqa: F401
