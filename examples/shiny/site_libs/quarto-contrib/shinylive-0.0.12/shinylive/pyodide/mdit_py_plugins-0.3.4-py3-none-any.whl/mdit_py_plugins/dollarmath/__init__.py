from .index import dollarmath_plugin  # noqa F401
