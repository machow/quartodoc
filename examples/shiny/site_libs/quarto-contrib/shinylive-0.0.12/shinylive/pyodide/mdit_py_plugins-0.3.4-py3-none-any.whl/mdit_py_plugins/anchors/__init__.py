from .index import anchors_plugin  # noqa F401
