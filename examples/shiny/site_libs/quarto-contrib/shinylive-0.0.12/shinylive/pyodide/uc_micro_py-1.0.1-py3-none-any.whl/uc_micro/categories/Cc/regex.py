REGEX = r"[\0-\x1F\x7F-\x9F]"
