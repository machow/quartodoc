from .categories import Cc, Cf, P, Z
from .properties import Any

__version__ = "1.0.1"
